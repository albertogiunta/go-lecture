package main
import "fmt"

func printAsync(from string) {
    for i := 0; i < 3; i++ {
        fmt.Println(from, ":", i)
    }
}

func main() {
    printAsync("direct")         // function executed synchronously
    
    go printAsync("goroutine")      // function executed asynchronously with goroutine
    
    go printAsync(msg string) { 
        fmt.Println(msg)            // anonymous function inside goroutine
    }("going")
    
    var input string
    fmt.Scanln(&input)
    fmt.Println("done")
}