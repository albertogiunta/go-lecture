func FirstFetchAmong(replicas ...SearchFunc) SearchFunc {
	return func(query string) Result {
    	// TODO create a buffered channel of type Result and as long as the number of replicas that were passed in input
    	// TODO create an inner function that given a index runs the replicated function at that index of replicas
    	// TODO launch this function in a new goroutines for every index of replicas
    	// TODO return the very first value received on the channel
		return nil
	}
}