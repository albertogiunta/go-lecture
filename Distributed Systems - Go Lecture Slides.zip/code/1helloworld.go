package main

import "fmt" // the standard library

func main() {
	fmt.Printf("Hello, world.\n")
}