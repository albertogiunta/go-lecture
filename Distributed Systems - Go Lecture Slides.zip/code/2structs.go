package main
import "fmt"

type person struct {
    name string
    age  int
}

func main() {
    fmt.Println(person{"Bob", 20}) // create a new struct.
    // the & creates a pointer to the struct
    fmt.Println(&person{name: "Ann", age: 40}) 
    s := person{name: "Sean", age: 50}
    fmt.Println(s.name) // access struct fields with a dot.
    sp := &s
    fmt.Println(sp.age) // struct pointers are deferentiated
    sp.age = 51 // Structs are mutable.
    fmt.Println(sp.age)
}
