func SearchReplicated(query string, timeout time.Duration) ([]Result, error) {
	// TODO same as you did in timeout, but this time use the replicated*FakeSearchFunctions
	// TODO also go complete the FirstFetchAmong function in searchUtils
	return nil, nil
}