// serial, parallel, with timeout
var (
	Web = FakeSearch("web", "Distributed Systems are the best!", "http://apice.unibo.it/xwiki...")
	Image = FakeSearch("image", "But what's really a distributed system?", "https://www.unibo.it/uniboweb...")
	Video = FakeSearch("video", "Cool video about distributed systems", "https://www.youtube.com/watch?v=...")
)

// distributed
var (
	replicatedWebFakeSearch = FirstFetchAmong(Web1, Web2)
	replicatedImageFakeSearch = FirstFetchAmong(Image1, Image2)
	replicatedVideoFakeSearch = FirstFetchAmong(Video1, Video2)
	
	Web1 = FakeSearch("web1", "Distributed Systems are the best!", "http://apice.unibo.it/xwiki...")
	Web2 = FakeSearch("web2", "Distributed Systems are the best!", "http://apice.unibo.it/xwiki...")
	Image1 = FakeSearch("image1", "But what's really a distributed system?", "https://www.unibo.it/uniboweb...")
	Image2 = FakeSearch("image2", "But what's really a distributed system?", "https://www.unibo.it/uniboweb...")
	Video1 = FakeSearch("video1", "Cool video about distributed systems", "https://www.youtube.com/watch?v=...")
	Video2 = FakeSearch("video2", "Cool video about distributed systems", "https://www.youtube.com/watch?v=...")
)
