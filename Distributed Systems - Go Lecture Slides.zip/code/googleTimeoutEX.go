func SearchTimeout(query string, timeout time.Duration) ([]Result, error) {
	// should return the same result in the same way as the SearchParallel function, but only if a timeout doesn't occur
	// TODO use the timer and the select statement inside the result array to either receive the search results from
	// the channel you created before, or return with what you have when the timer expires
	// HINT you can think of the timeout as a message on a whatever channel, also return a proper error string
	timer := time.After(timeout)
	
	return nil, nil
}