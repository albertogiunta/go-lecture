// select blocks on multiple channel operations
// if one unblocks the corresponding case is executed
func doStuff(channelOut, channelIn chan int) {
    select {
    case channelOut <- 42:
        fmt.Println("Write 42 into channelOut")
    case x := <- channelIn:
        fmt.Println("Save from channelIn into x")
    case <-time.After(time.Second * 1):
        fmt.Println("Timeout received. Not going to accept any other message here.")
    }
}