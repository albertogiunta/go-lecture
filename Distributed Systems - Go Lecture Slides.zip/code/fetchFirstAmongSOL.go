func FirstFetchAmong(replicas ...SearchFunc) SearchFunc {
	return func(query string) Result {
		c := make(chan Result, len(replicas))
		searchReplica := func(i int) {
			c <- replicas[i](query)
		}
		for i := range replicas {
			go searchReplica(i)
		}
		return <-c
	}
}
