// function that will be passed around to be executed in all the different ways (serial, parallel etc.)
type SearchFunc func(query string) Result

// the resulting data type of a Search
type Result struct {
	Title, URL string
}

// the data type we'll use to display the results on screen
type Response struct {
	Results []Result
	Elapsed time.Duration
}

// function that will be passed around to be executed in all the different ways (serial, parallel, with timeout, distributed)
func FakeSearch(kind, title, url string) SearchFunc {
	return func(query string) Result {
		time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond) // artificial delay for instructional reasons
		return Result{
			Title: fmt.Sprintf("%s(%q): %s", kind, query, title),
			URL:   url,
		}
	}
}