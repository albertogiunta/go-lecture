package main
import "fmt"

func player(playerName string, ch chan string, rounds int) {
  for i := 0; i < rounds; i++ {
  	<-ch
  	fmt.Println(playerName)
  	ch <- "unlock"
  }
}

func main() {
  fmt.Println("Welcome to the Ping Pong Game!")
  
  rounds := 10
  
  var sharedChannel chan string = make(chan string)
  
  go player("ping", sharedChannel, rounds)
  go player("pong", sharedChannel, rounds)
  
  sharedChannel <- "init"
  
  var input string
  fmt.Scanln(&input)
}
