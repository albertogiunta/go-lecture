func SearchParallel(query string) ([]Result, error) {
	// should return the same result as the SearchSerial function, but the search should be parallelized
	// TODO create a channel of type Result and use Goroutines to parallelize the work you did in SearchSerial
	// HINT send each search result on the channel and receive those results inside the array of results
	return []Result{}, nil
}